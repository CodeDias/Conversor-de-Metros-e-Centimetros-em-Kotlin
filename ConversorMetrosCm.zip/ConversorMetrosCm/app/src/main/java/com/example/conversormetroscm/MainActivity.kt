package com.example.conversormetroscm

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val medida = findViewById<EditText>(R.id.et_medida)

        val btn_escolhametros = findViewById<Button>(R.id.btn_escolhametros)
        btn_escolhametros.setOnClickListener {
            // Extrair valores dos EditText e converter para Int
            val medidaInt = medida.text.toString().toIntOrNull() ?: 0

            // Passar os valores inteiros para a função calcular
            calcularm(medidaInt)
        }

        val btn_escolhacm = findViewById<Button>(R.id.btn_escolhacm)
        btn_escolhacm.setOnClickListener {
            // Extrair valores dos EditText e converter para Int
            val medidaInt = medida.text.toString().toIntOrNull() ?: 0

            // Passar os valores inteiros para a função calcular
            calcularcm(medidaInt)
        }
    }

    fun calcularm(medida: Int){

        val tv_resultado = findViewById<TextView>(R.id.tv_resultado)
        val medida = (medida * 100) // calcular a medida de metros para centimetros

        tv_resultado.setText("O valor em Centímetros é:  ${medida}")

    }

    fun calcularcm(medida: Int){

        val tv_resultado = findViewById<TextView>(R.id.tv_resultado)
        val medida = (medida / 100) // calcular a medida de centimetros para metros

        tv_resultado.setText("O valor em Metros é:  ${medida}")

    }
}